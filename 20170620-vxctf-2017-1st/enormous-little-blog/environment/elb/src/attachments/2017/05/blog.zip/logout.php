<?php
    setcookie('esblog', NULL, time() + 1);
    header('Location: .');
?>